DIM = 101
TIME = 0

COLORS = ['orange', 'yellow', 'blue', 'purple', 'pink', 'brown']
