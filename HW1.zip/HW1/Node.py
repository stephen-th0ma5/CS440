class Node:

    def __init__(self, value, next):
        self.value = value
        self.next = next
